<?php
$servername="localhost";
$username="root";
$password="";

$database="dbravi";

$conn= mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die( "connection not succesccfully");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
         
        form{
            width:460px;
            height: 300px;
            /* border: 2px solid black; */

            background-color:gray;
            margin-left:470px;
            margin-top:210px;
            box-shadow:1px 1px 10px black;
        }
        .upperLin{
            width:100%;
            background-color:black;
            height: 30px;
            color:white;
            text-align:center;
            font-size:23px;
        }
        .username{
            margin:34px;
        }
        .username label{
            font-size:25px;
        }
        .username label {
            outline:none;
            background-color: gray;
        }
        .username input{
            margin-top:10px;
            width:70%;
            height: 28px;
            border:none;
        }
        /* .username input:placeholder{
            font-size:200px;
        } */
        .password{
            margin:34px;
        }
        .password label{
            font-size:25px;
           
        }
        .password input{
            margin-top:10px;
            width:70%;
            height: 28px;
            border:none;
        }
        .button button{
            padding:3px 15px;
            margin-left: 32px;
            font-size:15px;
            background-color:blue;
            color:white;
        }
    </style>
</head>
<body>
    <?php
      if (isset($_POST['submit'])){
        // echo " have a submitted";
          
        $username=$_POST['uname'];       
        
        $pword=$_POST["pword"];

        $sql= "INSERT INTO `copy` ( `username`, `password`) VALUES ( '$username', '$pword')";
        $result= mysqli_query($conn , $sql);
     
    }
     

    ?>


    <form action="welcome.php" method="post">
        <div class="upperLin">Login form</div>
        <div class="username">
        <label for=""> Username</label><br>
        <input type="text" placeholder="Enter your username" name="uname">
        </div>
        <div class="password">
        <label for="">password</label><br>
        <input type="password"   id="" placeholder="ENter your password" name="pword">
        </div>
        <div class="button">
            <button name="submit">submit</button>
        </div>
    </form>
</body>
</html>